<!doctype html>
<html lang="en">
  <head>
    <?php echo $__env->make('assets.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <body>
  	<?php echo $__env->make('assets.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <br><br>
  	<?php echo $__env->yieldContent('konten'); ?>

  	<div class="bg-dark" id='footer'>
  		<div class="container text-white">
  			<div class="row">
  				<div class="col-md-4">
  					<h1 class="text-danger">
  						Mega Shop
  					</h1>
  					<p>Jl. Sirnagalih <br>Desa Megamendung <br>Kecamatan Megamendung <br>Bogor - Jawa Barat</p>
  				</div>
  				<div class="col-md-4 text-white">
  					<h3>Link Cepat :</h3>
  					<ul>
  						<li><a href="/" class=" text-white">Home</a></li>
  						<li><a href="/toko" class=" text-white">Toko</a></li>
  						<li><a href="/tentang" class=" text-white">Tentang</a></li>
  					</ul>
  				</div>
  				<div class="col-md-4">
  					<h3>Ikuti Kami :</h3>
  					<a href="https://facebook.com/arwani.maulana.5" class="text-white"><i class="fab fa-facebook"></i></a>
  					<a href="https://instagram.com/megadigi12" class="text-white"><i class="fab fa-instagram"></i></a>
  					<hr>
  					<p>
  					  &copyCopyright MegaDigi 2021
  					</p>
  				</div>
  			</div>
  		</div>
  	</div>
    <?php echo $__env->make('assets.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH C:\laraproject\megashop\resources\views/main.blade.php ENDPATH**/ ?>