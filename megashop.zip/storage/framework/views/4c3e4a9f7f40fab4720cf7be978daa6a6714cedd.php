
<?php $__env->startSection('konten'); ?>
<?php
$kategories = ['all','scripts','laptop','hp','jasa','lainnya'];
?>
<div class="bg-light" style="padding-top: 20px; padding-bottom: 20px;">
	<div class="container">
		
		<ul class="nav">
			<?php $__currentLoopData = $kategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  <li class="nav-item">
		    <a class="nav-link <?php if($is_active == $kategori): ?> bg-white  <?php endif; ?>" href="/toko/<?php echo e($kategori); ?>" style="color: black;"><?php echo e($kategori); ?></a>
		  </li>
		  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
		
		
		<div class="row bg-white" style="padding: 20px;">
			
			<?php for($i = 0; $i <10 ; $i++): ?>
			<div class="col-md-5 me-4 ms-4 mt-2 mb-2 shadow-lg p-3 mb-5 bg-body rounded" style="overflow: hidden;">
				<div class="box-list">
					<div class="row">
						<div class="col-4" style="padding: 0px;">
							<img src="../img/barang1.jpg">
						</div>
						<div class="col-8">
							<h4>
								Nama Barang
							</h4>
							<hr>
							<p>
								Rp 0000,- | <a href="/barang/<?php echo e($i); ?>">
									Selengkapnya
								</a>
							</p>
						</div>
					</div>
				</div>
			</div>		
			<?php endfor; ?>
			
		</div>
		
	</div>
</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laraproject\megashop\resources\views/toko.blade.php ENDPATH**/ ?>