
<?php $__env->startSection('konten'); ?>
	<div class="bg-light">
		<br><br><br>
		<div class="form bg-white">
			<h1 class="text-center">Login</h1>
			<br>
			<div class="container">
				<form action="" method="post">
					<?php echo csrf_field(); ?>
					<div class="form-floating mb-3">
					  <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com" value="<?php echo e(old('email')); ?>">
					  <label for="email">Email address</label>
					</div>
					<div class="form-floating">
					  <input type="password" class="form-control" id="password" name="password" placeholder="Password">
					  <label for="password">Password</label>
					</div><br>
					<button type="submit" class="btn btn-primary">Login</button>
				</form>
				<br>
			</div>
		</div>
		<br>
		<p class="text-center">Belum punya akun? <a href="/register">Buat Akun</a></p>
		<br><br><br>
	</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laraproject\megashop\resources\views/login.blade.php ENDPATH**/ ?>