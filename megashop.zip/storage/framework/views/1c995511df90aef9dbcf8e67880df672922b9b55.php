
<?php $__env->startSection('konten'); ?>
<div class="bg-light"><br>
	<div class="container bg-white">
		<div style="width: 300px; height: 300px; overflow: hidden;" class="mx-auto">
			<img <?php if(auth()->user()->image!=''): ?>src="img/<?php echo e(auth()->user()->image); ?>"<?php else: ?> src="img/undraw_profile.svg"<?php endif; ?> class="img-thumbnail rounded-circle" style="width: 100%">
		</div>
		<div class="bg-danger container text-white">
			<h1>Informasi Akun</h1>
		</div>
		<div class="bg-light container">
			<a href="/editprofil" class="btn btn-primary">Lengkapi Informasi Akun</a>
			<a href="/editfoto" class="btn btn-primary">Ganti Foto</a>
			<div class="row">
				<div class="col-md-6">
					<h2>Profil</h2>
					<table>
						<tr>
							<td>Nama Lengkap</td>
							<td>: <?php if(auth()->user()->name != ''): ?><?php echo e(auth()->user()->name); ?><?php else: ?> Belum Diisi <?php endif; ?></td>
						</tr>
						<tr>
							<td>Username</td>
							<td>: <?php echo e(auth()->user()->username); ?></td>
						</tr>
						<tr>
							<td>Email</td>
							<td>: <?php echo e(auth()->user()->email); ?></td>
						</tr>
						<tr>
							<td>No Hp</td>
							<td>: <?php echo e(auth()->user()->no_hp); ?></td>
						</tr>
					</table>
				</div>
				<div class="col-md-6">
					<h2>Alamat</h2>
					<table>
						<tr>
							<td>Provinsi</td>
							<td>: <?php if(auth()->user()->origin != ''): ?><?php echo e($provinsi); ?><?php else: ?> Belum Diisi <?php endif; ?></td>
						</tr>
						<tr>
							<td>Kota</td>
							<td>: <?php if(auth()->user()->city != ''): ?><?php echo e($kota); ?><?php else: ?> Belum Diisi <?php endif; ?></td>
						</tr>
						<tr>
							<td>Alamat</td>
							<td>: <?php if(auth()->user()->alamat != ''): ?><?php echo e(auth()->user()->alamat); ?><?php else: ?> Belum Diisi <?php endif; ?></td>
						</tr>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laraproject\megashop\resources\views/profil.blade.php ENDPATH**/ ?>